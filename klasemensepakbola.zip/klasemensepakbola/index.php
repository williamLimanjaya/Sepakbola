<?php
echo "<script> location ='klub.php';</script>";
